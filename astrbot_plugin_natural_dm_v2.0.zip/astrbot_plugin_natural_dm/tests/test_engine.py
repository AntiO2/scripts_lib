import unittest
from astrbot_plugin_natural_dm.engine import (normalize_system,find_class,make_character,
    dnd_roll,dh_roll,dnd_attack,DND_CLASSES,DAGGER_CLASSES)

class TestRules(unittest.TestCase):
    def test_rulesets(self):
        self.assertEqual(normalize_system('我想玩匕首心'),'daggerheart')
        self.assertEqual(normalize_system('DND2014'),'dnd2014')
        self.assertEqual(normalize_system('我想玩龙与地下城'),'dnd2024')
    def test_classes(self):
        self.assertEqual(len(DND_CLASSES),12)
        self.assertEqual(len(DAGGER_CLASSES),9)
        self.assertEqual(find_class('我想当圣骑士','dnd2024'),'圣骑士')
        self.assertEqual(find_class('我想玩守护者','daggerheart'),'守护者')
        self.assertEqual(find_class('我想玩法师','daggerheart'),'法师')
        self.assertIsNone(find_class('我想玩圣骑士','daggerheart'))
    def test_roll(self):
        c=make_character('42','a','圣骑士','dnd2024')
        self.assertEqual(dnd_roll(c,'力量',12,die=lambda x:10)['total'],13)
        self.assertFalse(dnd_roll(c,'力量',30,die=lambda x:20)['success'])
        self.assertTrue(dnd_attack(c,ac=30,die=lambda x:20)['hit'])
        h=make_character('44','b','守护者','daggerheart')
        r=dh_roll(h,'力量',30,die=lambda x:4)
        self.assertTrue(r['critical'])
        self.assertTrue(r['success'])
    def test_uid(self):
        self.assertNotEqual(make_character('1','A','法师','dnd2014')['uid'],
                            make_character('2','A','法师','dnd2014')['uid'])

if __name__=='__main__':unittest.main()
