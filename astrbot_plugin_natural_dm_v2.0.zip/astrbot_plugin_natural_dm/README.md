# Natural DM v2.0 — QQ 自然语言 DM

**这不是 v1 的升级补丁，而是独立的事件监听器实现**

## 使用

1. 禁用或移走旧插件 `astrbot_plugin_dual_dm`，否则 `/dm` 命令冲突
2. 启用 `astrbot_plugin_natural_dm`，在 AstrBot 里配置 DeepSeek 聊天 Provider
3. 在群里 **@机器人 开始游戏**
4. 开团人自然语言回复“玩 D&D 5e”或“玩匕首心”
5. 各群友直接说“我玩法师”“我想当圣骑士”等，机器人按不同 QQ ID 记录角色
6. 开团人说 **开始冒险**，进入剧情
7. 之后**无需 @**，直接说“我观察门锁”“我上前交涉”“我打他”，插件判定后自己掷骰、回复

命令 `/dm help` `/dm status` `/dm whoami` `/dm sheet` `/dm players` `/dm pause` `/dm resume` `/dm stop` `/dm reset CONFIRM` 只供管理员/排查使用

## 数据与隔离

- 以平台 + 群号为键，每个角色再以 QQ ID 存储，不依赖群名片
- 通过 AstrBot 的 KV 数据库持久化，重启不丢进度
- 冒险启用时，插件接管该群所有普通文本消息，防止默认 DeepSeek 回复叠加；**在这一群里其他聊天插件的普通消息处理可能受到影响**，暂停游戏时仍不放行普通聊天；`/dm stop` 后恢复
- 只在新游戏启动时要求 `@`；如果 NapCat 没有正常提供 At 消息段，首次激活可能失败，排查请查看运行日志

## 原人格

内置了你此前确认过的「高强度互联网冲浪选手 V4」提示词快照（`persona_style.txt`），插件**不修改 AstrBot 后台保存的人格**。若后台人格后来有修改，请自行更新此文件并重启插件，否则插件里使用的仍是 V4 快照

## 规则边界

- 2014/2024 D&D 5e：中文12职业识别 + 简化一级人物卡、基础 d20 能力检定和武器攻击，程序掷真随机数
- Daggerheart：9 核心职业识别 + 希望/恐惧双 d12 检定与简化 Hope；不自动处理完整的子职业/领域卡、战斗、护甲与复杂资源
- 简化起始角色的 HP、AC 和部分修正是**演示数值，并非完整 SRD 严格建卡结果**；不可用于正式规则合规战斗
- DM 模型可自行决定是否检定，数值由程序决定，LLM 的裁定**可能出错**。特殊技能、豁免、法术、装备、回合行动经济及敌方血量没有全部自动化
- 部分场景含原创敌人简化 AC/HP，只有它们被显式定义后才自动结算敌人 HP
- 当前包没有内置完整商业手册与商业战役。内置两套原创冒险，用户自有 TXT/MD 规则可放入数据目录书库，按关键词检索；这不是完整 RAG
- 提供规则书入口 https://www.dndbeyond.com/srd 和 https://www.daggerheart.com/srd/

## 导入个人规则资料

通过服务器把 UTF-8 的 `.txt` / `.md` 放到宿主机：

```
~/bots/qq/data/plugin_data/astrbot_plugin_natural_dm/books/dnd2024/
~/bots/qq/data/plugin_data/astrbot_plugin_natural_dm/books/dnd2014/
~/bots/qq/data/plugin_data/astrbot_plugin_natural_dm/books/daggerheart/
```

每轮仅检索最多 2 份资料的短摘录。PDF 请先自行转换为文本

## 部署

```bash
cd ~/bots/qq
sudo mv data/plugins/astrbot_plugin_dual_dm data/plugins/astrbot_plugin_dual_dm.disabled  # 如果存在
sudo unzip -oq astrbot_plugin_natural_dm_v2.0.zip -d data/plugins/
sudo docker restart astrbot
sudo docker logs astrbot 2>&1 | grep -Ei 'natural_dm|Traceback|ERROR'
```

注意：**不要将 `.disabled` 目录继续放在 data/plugins 下**，AstrBot 可能仍会扫描它。建议移动到 `~/bots/qq/backup/`，不要直接删除旧数据

## 验收清单

- 一人在群里 @机器人 开始游戏，机器人询问 D&D 或匕首心
- 另一人不 @ 说“我要当法师”，/dm players 确认为另一 QQ ID
- 开团人“开始冒险”后，任一群友直接说“我偷偷接近守卫”，能触发回复或检定
- 骰点结果来自 `engine.py`，不是模型自己说的骰面
- `/dm pause`、`/dm resume`、`/dm stop` 持久化后正常运行

**目前只做了本地代码/模拟接口测试，未连接你腾讯云机器、QQ 平台或 DeepSeek API 进行真实端到端测试**
