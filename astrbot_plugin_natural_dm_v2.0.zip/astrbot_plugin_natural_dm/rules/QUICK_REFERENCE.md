# 游戏规则速查（仅供引导，不等于完整官方规则）

D&D 5e 2014/2024：能力检定通常为 d20 加属性修正以及适用的熟练加值，对比 DC。优势/劣势掷两个 d20 取高/低。攻击检定通常对抗 AC；攻击自然 1 失手，自然 20 命中并重击。能力检定天然 1/20 通常不代表必定失败/成功。具体职业、特性、法术需对应版本的 SRD。

Daggerheart：行动骰为 Hope d12、Fear d12，加相关特质和适用调整值。相同骰面为 critical success；更高的骰子决定 with Hope 或 with Fear。实际结算 Hope/Fear、压力、HP 和护甲依规则场景裁定；角色卡子职业/领域卡未在这个轻量引擎中自动执行，不能虚构其效果。

官方资料：D&D: https://www.dndbeyond.com/srd ; Daggerheart: https://www.daggerheart.com/srd/

内置职业卡是帮助零基础玩家快速开始的简化数值模板；并非官方角色卡全部数据。用户可以把自有的规则 TXT/MD 放在 plugin_data/astrbot_plugin_natural_dm/books/<ruleset>/，插件会按关键词取少量相关摘录；不得把缺失资料说成已加载。
