"""Standalone deterministic mechanics and state transitions for a natural-language GM."""
from __future__ import annotations
import re
import secrets
import time

SYSTEMS = {'dnd2014': 'D&D 5e（2014）', 'dnd2024': 'D&D 5e（2024）', 'daggerheart': '匕首心 Daggerheart'}
DND_CLASSES = {
 '野蛮人': ('barbarian','力量','近战爆发'), '吟游诗人': ('bard','魅力','交涉与法术'),
 '牧师': ('cleric','感知','神术与支援'), '德鲁伊': ('druid','感知','自然法术'),
 '战士': ('fighter','力量','武器与防护'), '武僧': ('monk','敏捷','灵活近战'),
 '圣骑士': ('paladin','力量','守护与圣光'), '游侠': ('ranger','敏捷','远程与追踪'),
 '游荡者': ('rogue','敏捷','潜行与技巧'), '术士': ('sorcerer','魅力','天赋施法'),
 '邪术师': ('warlock','魅力','契约魔法'), '法师': ('wizard','智力','学习型施法'),
}
DAGGER_CLASSES = {
 '吟游诗人':('bard','风度'), '德鲁伊':('druid','直觉'), '守护者':('guardian','力量'),
 '游侠':('ranger','敏捷'), '游荡者':('rogue','灵巧'), '炽天使':('seraph','风度'),
 '术士':('sorcerer','本能'), '战士':('warrior','力量'), '法师':('wizard','知识'),
}
DND_STATS=['力量','敏捷','体质','智力','感知','魅力']
DH_STATS=['敏捷','力量','灵巧','本能','风度','知识']
EXTRA_ALIASES={
 '盗贼':'游荡者','刺客':'游荡者','骑士':'圣骑士','奶妈':'牧师',
 '魔法师':'法师','fighter':'战士','wizard':'法师','rogue':'游荡者',
 'cleric':'牧师','paladin':'圣骑士','ranger':'游侠','barbarian':'野蛮人',
 'monk':'武僧','bard':'吟游诗人','druid':'德鲁伊','warlock':'邪术师',
 'sorcerer':'术士','guardian':'守护者','warrior':'战士','seraph':'炽天使'
}
SKILLS={
 '运动':'力量','体操':'敏捷','巧手':'敏捷','隐匿':'敏捷','奥秘':'智力',
 '历史':'智力','调查':'智力','自然':'智力','宗教':'智力','驯兽':'感知',
 '洞悉':'感知','医药':'感知','察觉':'感知','生存':'感知',
 '欺瞒':'魅力','威吓':'魅力','表演':'魅力','游说':'魅力',
 '感知':'感知','侦查':'感知','潜行':'敏捷','说服':'魅力','敏捷':'敏捷','力量':'力量',
 '智力':'智力','魅力':'魅力','体质':'体质',
}

def normalize_system(s):
 t=str(s).lower().replace(' ','')
 if any(x in t for x in ('匕首心','daggerheart','dh')): return 'daggerheart'
 if any(x in t for x in ('2014','5.1')): return 'dnd2014'
 if any(x in t for x in ('2024','5.2')): return 'dnd2024'
 if any(x in t for x in ('dnd','d&d','龙与地下城','第五版','5e')): return 'dnd2024'
 return None

def find_class(message,system):
 aliases={**EXTRA_ALIASES}
 avail = DAGGER_CLASSES if system=='daggerheart' else DND_CLASSES
 # aliases are applied only when the translated class exists in this ruleset
 names=sorted(set(avail)|set(aliases),key=len,reverse=True)
 text=str(message).lower()
 for name in names:
  mapped=aliases.get(name,name)
  if mapped in avail and name.lower() in text:
   return mapped
 return None

def fresh_campaign(owner,umo):
 return {'phase':'choose_system','owner':str(owner),'umo':umo,'system':None,'players':{},
  'adventure':None,'scene':0,'revealed':[], 'history':[], 'flags':{},'paused':False,
  'last_user':time.time(),'last_nudge':0,'version':2,'turn':0}

def make_character(uid,nickname,classname,system):
 avail=DAGGER_CLASSES if system=='daggerheart' else DND_CLASSES
 if classname not in avail: raise ValueError('不支持的职业')
 en,main,*_=avail[classname]
 stats={k:0 for k in (DH_STATS if system=='daggerheart' else DND_STATS)}
 stats[main]=2 if system=='daggerheart' else 3
 second=('敏捷' if main!='敏捷' else '感知') if system!='daggerheart' else ('灵巧' if main!='灵巧' else '力量')
 stats[second]=1 if system=='daggerheart' else 2
 if system=='daggerheart':
  char={'hp':6,'hp_max':6,'hope':2,'stress':0,'evasion':10,'armor':0,'resources':{},'stats':stats}
 else:
  char={'hp':12,'hp_max':12,'ac':15 if classname in ('战士','圣骑士','牧师') else 12,
   'proficiency':2,'stats':stats,'resources':{},'weapon':{'dice':'1d8','stat':main}}
 char.update({'uid':str(uid),'nickname':str(nickname)[:40],'name':str(nickname)[:30],
  'class':classname,'class_en':en,'ready':True,'simplified':True})
 return char

def dice(sides):return secrets.randbelow(sides)+1

def dnd_roll(character,ability,dc,advantage='normal',die=dice):
 if ability not in DND_STATS: ability=SKILLS.get(ability,'感知')
 dc=max(5,min(30,int(dc)))
 faces=[die(20),die(20)] if advantage in ('adv','dis') else [die(20)]
 face=max(faces) if advantage=='adv' else min(faces) if advantage=='dis' else faces[0]
 modifier=int(character['stats'].get(ability,0))
 total=face+modifier
 # Ability checks do not automatically critically succeed/fail on nat 20/1
 return {'kind':'dnd','face':face,'faces':faces,'ability':ability,'mod':modifier,'total':total,
  'dc':dc,'success':total>=dc,'advantage':advantage}

def dh_roll(character,trait,dc,die=dice):
 if trait not in DH_STATS: trait='本能'
 h=die(12);f=die(12);mod=int(character['stats'].get(trait,0))
 total=h+f+mod; critical=(h==f)
 # This is an illustrative action roll; class cards, experiences, and conditions are not automated.
 return {'kind':'daggerheart','hope_die':h,'fear_die':f,'trait':trait,'mod':mod,
  'dc':max(5,min(30,int(dc))),'total':total,'critical':critical,
  'success':critical or total>=dc, 'with': '暴击' if critical else '希望' if h>f else '恐惧'}

def dnd_attack(character,ac=12,die=dice):
 ac=max(5,min(30,int(ac)))
 face=die(20); mod=int(character['stats'].get(character.get('weapon',{}).get('stat','力量'),0))+int(character.get('proficiency',2))
 hit=face==20 or (face!=1 and face+mod>=ac)
 damage=0
 if hit:
  damage=die(8)+max(0,int(character['stats'].get(character.get('weapon',{}).get('stat','力量'),0)))
  if face==20:damage+=die(8)
 return {'kind':'attack','face':face,'mod':mod,'ac':ac,'hit':hit,'damage':damage,'critical':face==20}

def add_history(state,who,text,limit=24):
 state['history']=(state.get('history',[])+[{'who':str(who)[:40],'text':str(text)[:400]}])[-limit:]
 state['turn']=state.get('turn',0)+1

def safe_reply(s):
 text=str(s or '').strip().strip('"').strip()
 return text[:900].rstrip('。．. ')
