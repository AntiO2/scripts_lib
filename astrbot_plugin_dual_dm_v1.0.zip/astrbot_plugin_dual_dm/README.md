# AstrBot Dual DM 1.0 · 双规则新手主持辅助插件

适用于 **AstrBot 4.29.3**（按公开插件 API 编写，需在真实容器上完成集成验证），与 NapCat/OneBot v11 配合。保留你已经设置的「高强度互联网冲浪选手」人格，**不修改原人格的 system_prompt 或 begin_dialogs**。仅在某 QQ 群开启 DM 模式时，给 DeepSeek 当轮请求添加稳定主持指引、身份表、已公开场景/线索及可检索的规则文本

## 包含 / 不包含

直接包含：
- D&D 5e 2014 (SRD 5.1) 和 2024 (SRD 5.2.1) 的独立规则模式
- Daggerheart (SRD 2.0) 模式，双骰，希望 / 恐惧结果与基础资源结算
- 2 个**原创**中文新手冒险（《雾港失踪案》《玻璃花园的最后一夜》），各 5 幕，公开叙述、可揭露线索、DM 指南、情节与结局
- QQ ID → 角色身份绑定，昵称可以改变，每群独立存档
- 掷骰、D&D 属性检定/优势/劣势/命中、匕首心双骰、角色预设、HP/Hope/Stress、事件日志、暂停/恢复
- 规则书 TXT/MD 本地检索，可以按所选规则切换；提供官方 SRD 下载脚本和 PDF 转文本脚本

**尚不包含**：
- 全 D&D 2014/2024 的完整建卡流程、全部职业/子职/专长/怪物/法术的可执行规则，自动战斗轮次或全部例外处理
- Daggerheart 的全部领域卡、敌人能力、伤害阈值与护甲槽自动化
- AI 不经人类同意自动判断线索解锁、自动变更资源、自动跨幕推进
- PDF 二进制文件。官方 SRD 的 PDF 在本次构建环境无法下载，因此给出已核实的官方下载 URL；上传用户拥有的文件后才能全文检索

这一版是可以安装体验并带新手进行**简化规则冒险**的功能型插件，不是两套系统全量数字规则引擎。对于职业法术、复杂战斗等问题，建议导入官方完整 SRD 并由真人复核 AI 裁定

## 安装

如果你之前装过旧的 `astrbot_plugin_dual_dm`，先备份，不要直接把两个不同版本并列安装

将包含 `astrbot_plugin_dual_dm/` 顶层文件夹的 ZIP 上传至腾讯云 Ubuntu 服务器 `~/bots/qq/`，执行：

```bash
cd ~/bots/qq
# 先备份旧插件和现有数据
mkdir -p backups
[ -d data/plugins/astrbot_plugin_dual_dm ] && cp -a data/plugins/astrbot_plugin_dual_dm "backups/astrbot_plugin_dual_dm_$(date +%F_%H%M%S)" || true
unzip -oq astrbot_plugin_dual_dm_v1.0.zip -d data/plugins/
sudo docker restart astrbot
sudo docker logs --tail 120 astrbot
```

持久化数据通过 AstrBot 的 KV 存储保存在数据目录，不保存在插件目录中。新插件沿用 `dual_dm:v1` 的键，**不会删除 v0.1 使用的 `ddm:v1` 旧状态**（但也不自动迁移，因此新建冒险）

若插件在 Dashboard 的“加载失败插件”里出现，请把 traceback（打码 Token / QQ 号）发给开发者，不要直接删除全部 AstrBot 数据

## 从零开团（首次接触桌面角色扮演游戏）

在 QQ 群依次发：

```
/dm help
/dm start dnd2024
/dm tutorial
/dm join 罗温
/dm class fighter
/dm sheet
/dm scene
```

第二位玩家可以用另一个 QQ 号：

```
/dm whoami
/dm join 伊拉
/dm class wizard
```

所有玩家 `whoami` 中的 QQ ID 应不同；模型的群聊上下文中，请打开 AstrBot 的用户标识（identifier）、群聊上下文感知，并关闭群用户隔离会话

玩家直接 @机器人描述行动，DM 会提示需要什么检定；例如：

```
/dm check dex 12
/dm check wis 13 adv
/dm attack 5 13
/dm roll 1d6+2
```

开启匕首心冒险：

```
/dm stop
/dm start daggerheart
/dm join 檐
/dm class guardian
/dm scene
/dm duality 2 12
/dm status
```

按幕推进：开团者（/dm start 的账号）确认玩家已经探索完毕，发送 `/dm next` 进入下一幕；也可以用 `/dm reveal 1` 向整个群公开当前幕第 1 条线索。**不能在群聊里调用任何所谓“GM 私密线索查看”命令**，避免对所有玩家泄底

`/dm stop` 关闭游戏模式并保留状态；`/dm reset CONFIRM` 真正删除本群状态。**下一次 `/dm start` 将重新开启新档，不是续档；要继续未完成的冒险，请保持 active 状态，用 `/dm pause` 暂停、`/dm resume` 恢复**

## 命令（/dm help 里也有）

| 命令 | 说明 |
|---|---|
| `/dm help` | 完整帮助 |
| `/dm start dnd2014` | 使用 2014 规则 + 原创雾港冒险 |
| `/dm start dnd2024` | 使用 2024 规则 + 原创雾港冒险 |
| `/dm start daggerheart` | 匕首心 + 原创玻璃花园冒险 |
| `/dm join 名字` | 当前 QQ ID 绑定角色 |
| `/dm class fighter` | 选择简化职业预设，可选职业见帮助 |
| `/dm whoami` | 检查 QQ 身份 |
| `/dm players` / `/dm sheet` | 玩家表 / 自己的简化卡 |
| `/dm scene` / `/dm next` | 显示当前幕 / 开团者推进 |
| `/dm reveal 1` | 开团者公开本幕指定线索 |
| `/dm rules` / `/dm tutorial` | 当前规则速查 / 新手入门 |
| `/dm roll 1d20+3` | 安全随机骰 |
| `/dm check dex 13 adv` | D&D 能力检定，adv/dis 可选 |
| `/dm attack 5 14` | D&D 命中与重击判定，伤害另掷 |
| `/dm duality 2 13` | 匕首心双骰+难度，自动计算基础 Hope/Fear/Stress 资源变动 |
| `/dm resource hp -2` | 调整本人资源，有日志，注意匕首心 HP 为标记槽位，别把伤害点直接等于 HP |
| `/dm books` / `/dm lookup 关键字` | 查询已导入的当前系统规则文本 |
| `/dm status` / `/dm log` / `/dm save` | 状态 / 最近事件 / 确认自动存档 |
| `/dm pause` / `/dm resume` | 仅开团者 |
| `/dm stop` / `/dm reset CONFIRM` | 退出（保留） / 删除当前群数据 |

## 导入你已拥有的规则书与模组

此版本不包含未经授权的整本付费书籍。能导入 PDF，转换为文本后供当前系统检索，不会将 PDF 文件自动上送到 DeepSeek（**被检索命中的文本片段会作为模型上下文发送到 DeepSeek API**，请确保你的资料适合这样使用）

步骤：

```bash
# 下载官方 SRD 到服务器（如网络访问 GitHub 慢，不影响本地已有的 PDF）
# 以下文件也可以在本地下载后上传服务器
bash data/plugins/astrbot_plugin_dual_dm/tools/download_srd.sh /tmp/dual_dm_srd

# 安装 PDF 文本提取工具（宿主机执行）
sudo apt-get update && sudo apt-get install -y poppler-utils

# 把你合法获取的 PDF 上传到 Ubuntu，例如 /home/ubuntu/books/xxx.pdf
python3 data/plugins/astrbot_plugin_dual_dm/tools/import_rules.py \
  dnd2024 /home/ubuntu/books/xxx.pdf \
  ~/bots/qq/data/plugin_data/astrbot_plugin_dual_dm/books

# 同理：dnd2014 / daggerheart
```

注意路径写的是**宿主机目录**。你从 `~/bots/qq/` 运行时，输出目录建议改用绝对路径：

```bash
python3 data/plugins/astrbot_plugin_dual_dm/tools/import_rules.py \
  daggerheart /home/ubuntu/books/daggerheart.pdf \
  "$(pwd)/data/plugin_data/astrbot_plugin_dual_dm/books"
```

QQ群中执行 `/dm books` 检查文件是否识别。文件只允许 `.txt` `.md` 本地检索，每个文件大小不超过 12MiB（转换后）。扫描版 PDF 可能无法提取文本，需用户自行 OCR

当前检索基于字符/词语匹配，不是向量检索；可以作为第一版规则参考，但不保证每次找到最相关条款。两个版本会分目录、不会混检

## 部署安全

- 6185 / 6099 是管理后台，不建议全网长期放行，推荐只允许自己公网 IP 或使用 SSH 隧道
- 不向群里打印 Token，不上传 QQ 用户名和密码
- 群成员 QQ ID 只用于角色绑定，无需抓取整群历史
- 提示词视玩家发言为不可信输入；规则检索命中的文本也只是资料，不作为系统命令
- 开团者身份绑定为 /dm start 发起人的 QQ 账号；请勿用可能被多人共享的机器人 QQ 号作为开团者

## 版权信息

见 `LICENSE_SOURCES.md`，D&D 官方 SRD CC BY 4.0 与 Daggerheart 官方 SRD/DPCGL 来源均已标明。两个冒险为插件原创

## 本地测试范围

- 纯 Python 规则单测：掷骰、检定、暴击、资源边界、文本检索
- `python -m compileall` 静态语法检查
- 可选模拟 AstrBot 接口做命令端到端测试
- 没有实际连接你的腾讯云 QQ 群或 DeepSeek API，因此不声称已经通过真实集成测试

## 导入自有模组（结构化场景）

如果你有自己购买的战役，**不能仅将 PDF 放入 `books` 就期待 AI 自动按章主持**。你需要把模组章节整理为 JSON 场景（可只用关键节点、公共描述、关键线索，不必复制整本内容），参考 `examples/custom_adventure_example.json`

保存为 `data/plugin_data/astrbot_plugin_dual_dm/adventures/你的英文ID.json`，JSON 内的 `id` 必须与文件名相同，`systems` 可以设置为 `dnd2014`、`dnd2024` 或 `daggerheart`，然后重启 AstrBot，再用 `/dm start dnd2024 你的英文ID` 启动。自定义冒险会以独立数据目录保存，不会被插件更新覆盖

通过 `/dm lookup` 查相关规则书的机制，实际战役章节依旧按照结构化场景控制；如果一段剧本原文涉及剧透，不要直接粘贴到 `public` 字段或模型长期人格里
