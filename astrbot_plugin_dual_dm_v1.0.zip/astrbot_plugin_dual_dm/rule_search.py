"""Read user-imported text rules; bounded local retrieval without vector DB."""
from __future__ import annotations
import re
from pathlib import Path
from functools import lru_cache

VALID_SYSTEMS={'dnd2014','dnd2024','daggerheart'}

def tokenize(s:str):
    s=s.casefold()
    return set(re.findall(r'[a-z][a-z0-9_-]{2,}|\d{2,}',s) + [s[i:i+2] for i in range(len(s)-1) if '\u4e00'<=s[i]<='\u9fff' and '\u4e00'<=s[i+1]<='\u9fff'])

@lru_cache(maxsize=24)
def load_chunks(filename:str,mtime:float):
    # Each document may be <= 12 MiB to limit memory and response time
    path=Path(filename)
    if path.stat().st_size >12*1024*1024:return []
    text=path.read_text(encoding='utf-8',errors='replace')
    lines=text.splitlines()
    chunks=[]; chunk=[]; length=0
    for line in lines:
        if length+len(line)>1100 and chunk:
            chunks.append('\n'.join(chunk))
            chunk=[];length=0
        # split exceptionally long single lines
        while len(line)>1100:
            chunks.append(line[:1100]);line=line[1100:]
        chunk.append(line);length+=len(line)+1
    if chunk:chunks.append('\n'.join(chunk))
    return chunks[:12000]

def lookup(base:Path,system:str,query:str,limit:int=2)->list[dict]:
    if system not in VALID_SYSTEMS:return []
    base=base.resolve(); directory=base/system
    if not directory.is_dir():return []
    words=tokenize(query)
    if not words:return []
    found=[]
    for file in sorted(directory.glob('*'))[:30]:
        if file.is_symlink() or file.suffix.casefold() not in {'.txt','.md'}:continue
        for i,chunk in enumerate(load_chunks(str(file),file.stat().st_mtime)):
            tokens=tokenize(chunk)
            common=words & tokens
            if not common:continue
            score=sum(min(6,len(t)) if any('\u4e00'<=c<='\u9fff' for c in t) else min(8,len(t)) for t in common)
            found.append((score,file.name,i,chunk))
    found.sort(key=lambda x:(-x[0],x[1],x[2]))
    return [{'source':name,'index':i,'text':chunk[:1100],'score':score} for score,name,i,chunk in found[:limit]]
