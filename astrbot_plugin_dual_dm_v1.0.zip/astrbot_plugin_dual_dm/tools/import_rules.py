"""Convert your own licensed PDF into local text for plugin lookup. Requires pdftotext or PyMuPDF."""
import sys,subprocess,shutil
from pathlib import Path
SYSTEMS={'dnd2014','dnd2024','daggerheart'}

def convert(pdf:Path,out:Path):
    if shutil.which('pdftotext'):
        subprocess.run(['pdftotext','-layout',str(pdf),str(out)],check=True)
    else:
        try:import fitz
        except ImportError:raise RuntimeError('需安装 poppler-utils (pdftotext) 或 pip install pymupdf')
        doc=fitz.open(pdf)
        with out.open('w',encoding='utf-8') as f:
            for page in doc:
                f.write(page.get_text()+'\n')

if __name__=='__main__':
    if len(sys.argv)!=4 or sys.argv[1] not in SYSTEMS:
        sys.exit('用法: python import_rules.py dnd2024 <自有规则书.pdf> <AstrBot/data/plugin_data/astrbot_plugin_dual_dm/books>')
    sysname,pdf,base=sys.argv[1],Path(sys.argv[2]).resolve(),Path(sys.argv[3]).resolve()
    if not pdf.is_file() or pdf.suffix.lower()!='.pdf':sys.exit('文件必须是本地 PDF')
    folder=base/sysname;folder.mkdir(parents=True,exist_ok=True)
    out=folder/(pdf.stem+'.txt')
    convert(pdf,out)
    print('已转换:',out,'字节:',out.stat().st_size)
