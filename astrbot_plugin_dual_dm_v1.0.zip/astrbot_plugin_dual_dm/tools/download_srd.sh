#!/usr/bin/env bash
set -euo pipefail
# Downloads official freely available SRDs to a local staging directory (they are not inside the ZIP)
DEST="${1:-$PWD/srd_downloads}"
mkdir -p "$DEST"
fetch() {
  local name="$1" url="$2"
  echo "Downloading $name from publisher..."
  curl -fL --retry 3 --connect-timeout 12 --max-time 180 "$url" -o "$DEST/$name"
}
fetch dnd_srd_5.1.pdf 'https://media.wizards.com/2023/downloads/dnd/SRD_CC_v5.1.pdf'
fetch dnd_srd_5.2.1.pdf 'https://media.dndbeyond.com/compendium-images/srd/5.2/SRD_CC_v5.2.1.pdf'
fetch daggerheart_srd_2.0.pdf 'https://www.daggerheart.com/wp-content/uploads/2026/08/DH_SRD_2_2026_08_25.pdf'
echo "Complete. Run tools/import_rules.py to prepare searchable text"
