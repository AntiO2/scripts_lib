"""Pure-Python, no-network mechanics and data validation for Dual DM."""
from __future__ import annotations
import re
import secrets
from dataclasses import dataclass

SYSTEMS = {
    'dnd2014': 'D&D 5e (2014, SRD 5.1)',
    'dnd2024': 'D&D 5e (2024, SRD 5.2.1)',
    'daggerheart': 'Daggerheart (SRD 2.0)',
}
BOOKS = {
 'dnd2014': 'https://media.wizards.com/2023/downloads/dnd/SRD_CC_v5.1.pdf',
 'dnd2024': 'https://media.dndbeyond.com/compendium-images/srd/5.2/SRD_CC_v5.2.1.pdf',
 'daggerheart': 'https://www.daggerheart.com/wp-content/uploads/2026/08/DH_SRD_2_2026_08_25.pdf',
}
DICE_RE = re.compile(r'^([1-9]\d?)d([1-9]\d{0,3})([+-]\d{1,4})?$', re.I)
ABILITY = {'str':'力量','dex':'敏捷','con':'体质','int':'智力','wis':'感知','cha':'魅力'}
CLASSES = {
    'dnd': {
        'fighter': {'display':'战士','stats':{'str':3,'dex':1,'con':2,'int':0,'wis':1,'cha':-1},'hp':12,'ac':16,'note':'适合新手：近战和保护队友；这里只是简化预设，并非官方建卡'},
        'rogue': {'display':'游荡者','stats':{'str':-1,'dex':3,'con':1,'int':1,'wis':1,'cha':2},'hp':9,'ac':14,'note':'适合新手：调查、潜行和交涉；这里只是简化预设，并非官方建卡'},
        'cleric': {'display':'牧师','stats':{'str':1,'dex':0,'con':2,'int':0,'wis':3,'cha':1},'hp':10,'ac':16,'note':'适合新手：支持与治疗；法术准备及资源需参照对应规则书'},
        'wizard': {'display':'法师','stats':{'str':-1,'dex':2,'con':1,'int':3,'wis':1,'cha':0},'hp':7,'ac':12,'note':'适合新手：法术与知识；法术列表需从规则资料核对'},
    },
    'daggerheart': {
        'guardian':{'display':'守护者','stats':{'agi':0,'str':2,'fin':0,'ins':1,'pre':-1,'kno':1},'hp':6,'stress':6,'hope':2,'note':'简化测试卡，阈值、护甲槽和领域卡需参照 SRD 完善'},
        'warrior':{'display':'战士','stats':{'agi':1,'str':2,'fin':0,'ins':0,'pre':-1,'kno':1},'hp':6,'stress':6,'hope':2,'note':'简化测试卡，领域卡与装备需参照 SRD 完善'},
        'rogue':{'display':'游荡者','stats':{'agi':2,'str':-1,'fin':1,'ins':1,'pre':1,'kno':0},'hp':6,'stress':6,'hope':2,'note':'简化测试卡，领域卡与经验需参照 SRD 完善'},
        'bard':{'display':'吟游诗人','stats':{'agi':0,'str':-1,'fin':1,'ins':1,'pre':2,'kno':0},'hp':6,'stress':6,'hope':2,'note':'简化测试卡，领域卡与经验需参照 SRD 完善'},
    }
}
DH_TRAITS = {'agi':'敏捷','str':'力量','fin':'灵巧','ins':'本能','pre':'风采','kno':'知识'}

@dataclass(frozen=True)
class Roll:
    faces: tuple[int,...]
    modifier: int
    total: int


def clean_name(name:str)->str:
    name=name.strip()
    if not 1 <= len(name) <= 24 or re.search(r'[\x00-\x1f<>\u2028\u2029]',name):
        raise ValueError('名字必须为 1–24 字符，不得包含换行或尖括号')
    return name


def roll(expr:str, rnd=None)->Roll:
    match=DICE_RE.fullmatch(expr.strip())
    if not match: raise ValueError('骰式格式为 NdS+M，例如 1d20+3')
    count,sides,mod=int(match[1]),int(match[2]),int(match[3] or 0)
    if not 1<=count<=30 or not 2<=sides<=1000 or not -1000<=mod<=1000:
        raise ValueError('骰子数量 1–30、面数 2–1000、修正 ±1000')
    rng=rnd or secrets.randbelow
    faces=tuple(rng(sides)+1 for _ in range(count))
    return Roll(faces,mod,sum(faces)+mod)


def dnd_check(modifier:int, dc:int, mode:str='normal',rnd=None):
    if not -100<=modifier<=100 or not 1<=dc<=50: raise ValueError('参数范围不合法')
    if mode not in {'normal','adv','dis'}: raise ValueError('第三参数填写 normal、adv 或 dis')
    rng=rnd or secrets.randbelow
    faces=[rng(20)+1 for _ in range(2 if mode!='normal' else 1)]
    chosen=max(faces) if mode=='adv' else min(faces) if mode=='dis' else faces[0]
    return {'faces':faces,'chosen':chosen,'total':chosen+modifier,'dc':dc,'success':chosen+modifier>=dc,'mode':mode}


def dnd_attack(bonus:int, ac:int,rnd=None):
    if not -100<=bonus<=100 or not 1<=ac<=50:raise ValueError('参数范围不合法')
    rng=rnd or secrets.randbelow
    face=rng(20)+1
    return {'face':face,'bonus':bonus,'total':face+bonus,'hit':face==20 or (face!=1 and face+bonus>=ac),'critical':face==20}


def daggerheart_duality(modifier:int, difficulty:int,rnd=None):
    if not -100<=modifier<=100 or not 1<=difficulty<=50:raise ValueError('参数范围不合法')
    rng=rnd or secrets.randbelow
    hope,fear=rng(12)+1,rng(12)+1
    critical=hope==fear
    result='critical' if critical else ('hope' if hope>fear else 'fear')
    return {'hope':hope,'fear':fear,'modifier':modifier,'total':hope+fear+modifier,'difficulty':difficulty,'success':critical or (hope+fear+modifier>=difficulty),'critical':critical,'dominant':result}


def template_for(system:str, role:str):
    typ='daggerheart' if system=='daggerheart' else 'dnd'
    if role not in CLASSES[typ]:raise ValueError('可选职业：'+', '.join(CLASSES[typ]))
    obj=CLASSES[typ][role].copy()
    obj['class']=role
    obj['hp_max']=obj['hp']
    obj['hp_current']=obj['hp']
    obj['stress_current']=0
    return obj


def resource_change(player:dict,which:str,delta:int)->int:
    if not -99<=delta<=99:raise ValueError('单次变化请在 ±99 以内')
    if which=='hp':
        max_hp=player.get('hp_max')
        if max_hp is None:raise ValueError('请先 /dm class 建卡')
        player['hp_current']=max(0,min(max_hp,int(player.get('hp_current',max_hp))+delta))
        return player['hp_current']
    elif which=='hope':
        if 'hope' not in player:raise ValueError('仅匕首心角色有 Hope')
        player['hope']=max(0,min(6,int(player['hope'])+delta))
        return player['hope']
    elif which=='stress':
        if 'stress' not in player:raise ValueError('仅匕首心角色有 Stress')
        player['stress_current']=max(0,min(player['stress'],int(player.get('stress_current',0))+delta))
        return player['stress_current']
    else:raise ValueError('资源仅支持 hp、hope、stress')
