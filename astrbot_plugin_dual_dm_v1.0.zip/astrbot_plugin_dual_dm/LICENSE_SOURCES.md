# Rule sources / Attribution

D&D 2014: System Reference Document 5.1 by Wizards of the Coast LLC, https://media.wizards.com/2023/downloads/dnd/SRD_CC_v5.1.pdf — Creative Commons Attribution 4.0, https://creativecommons.org/licenses/by/4.0/

D&D 2024: System Reference Document 5.2.1 by Wizards of the Coast LLC, https://www.dndbeyond.com/srd — Creative Commons Attribution 4.0, https://creativecommons.org/licenses/by/4.0/

Daggerheart: This product includes materials from the Daggerheart System Reference Document 2.0, © 2026 Critical Role, LLC. under the terms of the Darrington Press Community Gaming (DPCGL) License. More information can be found at https://www.daggerheart.com. There are no previous modifications by others.

The bundled adventure text is original, and no commercially sold copyrighted rulebooks or modules have been repackaged. Complete SRD PDFs are NOT bundled because the build environment could not retrieve the official PDFs; use tools/download_srd.sh or upload owned copies separately. The code is not an official licensed product or an official representative of Wizards or Darrington Press.
