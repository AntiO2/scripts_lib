import unittest,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine import roll,dnd_check,dnd_attack,daggerheart_duality,template_for,resource_change,clean_name
from rule_search import lookup

class EngineTest(unittest.TestCase):
 def test_dice(self):
  r=roll('2d6+3',rnd=lambda n: n-1)
  self.assertEqual(r.faces,(6,6));self.assertEqual(r.total,15)
  for expr in ['1d1','31d6','1d20+99999','__import__','2d6-1001']:
   with self.assertRaises(ValueError): roll(expr)
 def test_dnd_check(self):
  self.assertTrue(dnd_check(2,10,rnd=lambda _:9)['success'])
  self.assertEqual(dnd_check(2,19,'adv',rnd=lambda _:12)['total'],15)
  self.assertFalse(dnd_check(-1,20,rnd=lambda _:19)['success']) # d20 20 not auto-success on ability check
 def test_dnd_attack(self):
  self.assertTrue(dnd_attack(-4,22,rnd=lambda _:19)['critical'])
  self.assertFalse(dnd_attack(30,1,rnd=lambda _:0)['hit'])
 def test_duality(self):
  vals=iter([0,0]);r=daggerheart_duality(-50,50,rnd=lambda n:next(vals)) if False else None
  vals=iter([4,4]);r=daggerheart_duality(0,50,rnd=lambda n:next(vals))
  self.assertTrue(r['critical']);self.assertTrue(r['success'])
  vals=iter([11,0]);r=daggerheart_duality(0,10,rnd=lambda n:next(vals))
  self.assertEqual(r['dominant'],'hope')
 def test_resource(self):
  p=template_for('daggerheart','guardian')
  self.assertEqual(resource_change(p,'hope',8),6)
  self.assertEqual(resource_change(p,'stress',20),6)
  self.assertEqual(resource_change(p,'hp',-99),0)
  with self.assertRaises(ValueError):clean_name('A\nB')
 def test_text_lookup(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);(root/'dnd2024').mkdir();(root/'daggerheart').mkdir()
   (root/'dnd2024'/'rule.md').write_text('行动检定使用 d20 并与难度等级比较',encoding='utf-8')
   (root/'daggerheart'/'rule.md').write_text('Hope 骰和 Fear 骰，双骰相同就是暴击成功',encoding='utf-8')
   self.assertTrue(lookup(root,'dnd2024','行动检定'))
   self.assertFalse(lookup(root,'daggerheart','行动检定'))

if __name__=='__main__':unittest.main()
