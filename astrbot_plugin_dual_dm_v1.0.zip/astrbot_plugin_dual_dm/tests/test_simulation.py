"""Integration simulation with minimal fake AstrBot API, does not call QQ/LLM."""
import sys,types,unittest,asyncio,tempfile
from pathlib import Path
R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(R))

# Minimal mocks of the public AstrBot 4.x extension API
class GroupDec:
 def __call__(self,fn):
  fn.command=lambda name: (lambda x:x)
  return fn
class Filter:
 def command_group(self,*a,**kw):return GroupDec()
 def on_llm_request(self,*a,**kw):return lambda fn:fn
class FakeStar:
 def __init__(self,context):self.context=context;self.store={}
 async def get_kv_data(self,k,default=None):return self.store.get(k,default)
 async def put_kv_data(self,k,v):self.store[k]=v
 async def delete_kv_data(self,k):self.store.pop(k,None)
class TextPart:
 def __init__(self,text):self.text=text
 def mark_as_temp(self):return self
class Event:
 def __init__(self,uid='111',name='A'):
  self.uid=uid;self.name=name;self.message_str='我想调查门锁'
 def get_group_id(self):return 'group-99'
 def get_platform_id(self):return 'aiocqhttp'
 def get_sender_id(self):return self.uid
 def get_sender_name(self):return self.name
 def plain_result(self,msg):return str(msg)

def module(name,**attrs):
 m=types.ModuleType(name)
 for k,v in attrs.items():setattr(m,k,v)
 sys.modules[name]=m
module('astrbot')
module('astrbot.api')
module('astrbot.api.event',filter=Filter(),AstrMessageEvent=Event)
module('astrbot.api.provider',ProviderRequest=object)
module('astrbot.api.star',Context=object,Star=FakeStar)
module('astrbot.core')
module('astrbot.core.agent')
module('astrbot.core.agent.message',TextPart=TextPart)
module('astrbot.core.utils')
module('astrbot.core.utils.astrbot_path',get_astrbot_data_path=lambda:'/tmp/dual_dm_tests')
from astrbot_plugin_dual_dm.main import DualDM

async def collect(gen):
 return [item async for item in gen]

class SimulationTest(unittest.TestCase):
 def test_group_isolation_auth_prompt_and_roles(self):
  async def scenario():
   bot=DualDM(None)
   owner=Event('111','Owner'); player=Event('222','Friend')
   self.assertIn('已开团',(await collect(bot.start(owner,'dnd2024')))[0])
   self.assertIn('角色',(await collect(bot.join(owner,'罗温')))[0])
   self.assertIn('战士',(await collect(bot.choose_class(owner,'fighter')))[0])
   self.assertIn('角色',(await collect(bot.join(player,'莉亚')))[0])
   self.assertIn('法师',(await collect(bot.choose_class(player,'wizard')))[0])
   self.assertIn('QQ ID：111',(await collect(bot.whoami(owner)))[0])
   self.assertIn('QQ ID：222',(await collect(bot.whoami(player)))[0])
   self.assertIn('仅开团者',(await collect(bot.next_scene(player)))[0])
   self.assertIn('进入新场景',(await collect(bot.next_scene(owner)))[0])
   req=types.SimpleNamespace(system_prompt='原来的冲浪人格',extra_user_content_parts=[])
   await bot.inject_dm(player,req)
   self.assertTrue(req.system_prompt.startswith('原来的冲浪人格'))
   self.assertIn('当前发言人：Friend',req.extra_user_content_parts[0].text)
   self.assertNotIn('商人试图掩盖',req.extra_user_content_parts[0].text)
   self.assertIn('DM 已暂停',(await collect(bot.pause(owner)))[0])
   req2=types.SimpleNamespace(system_prompt='原人格',extra_user_content_parts=[])
   await bot.inject_dm(player,req2)
   self.assertEqual(req2.system_prompt,'原人格')
   self.assertIn('恢复',(await collect(bot.resume(owner)))[0])
   self.assertIn('已关闭',(await collect(bot.stop(owner)))[0])
  asyncio.run(scenario())

if __name__=='__main__':unittest.main()
