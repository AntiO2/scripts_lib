# Daggerheart / 匕首心 · 新手规则速查（原创概述，非完整 SRD）

- 玩家共同讲述冒险，行动存在戏剧性不确定性时才掷双骰
- 行动掷 Hope d12 + Fear d12 + 特质修正和适用加值，对比难度
- Hope 骰比 Fear 骰高，表示 with Hope；反之为 with Fear；两颗 d12 点数相同则 Critical Success，自动成功
- Success with Hope：成功并获得 1 Hope，聚光灯暂留玩家
- Success with Fear：成功但发生代价，GM 获得 1 Fear 并掌握聚光灯
- Failure with Hope：失败但获得 1 Hope，GM 获得聚光灯
- Failure with Fear：失败且有较大后果，GM 获得 1 Fear
- Critical Success：自动成功、得到 1 Hope、清除 1 Stress；攻击还涉及暴击伤害
- Hope 资源上限 6，GM Fear 上限 12。战斗为 Spotlight 推进而不是固定的 D&D 先攻轮次
- 伤害按 Major / Severe 阈值转换成 HP 标记，不是把原始伤害点数直接从 HP 中扣除
- 插件的 /dm class 提供教学用简化卡，没有完整的领域卡、Evasion、阈值、护甲槽、装备与全部职业能力

官方完整文档：https://www.daggerheart.com/wp-content/uploads/2026/08/DH_SRD_2_2026_08_25.pdf
